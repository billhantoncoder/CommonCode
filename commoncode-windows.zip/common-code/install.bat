@echo off
setlocal enabledelayedexpansion

echo =========================================
echo   CommonCode (.ccode) Installer
echo =========================================
echo.

:: 1. Define target directory in Local AppData
set "INSTALL_DIR=%LOCALAPPDATA%\CommonCode"

echo [*] Creating installation directory at:
echo     %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: 2. Check if PyInstaller binary exists in dist/ or local root
if exist "dist\ccode.exe" (
    echo [*] Copying compiled ccode.exe from dist...
    copy /Y "dist\ccode.exe" "%INSTALL_DIR%\ccode.exe" >nul
) else if exist "ccode.exe" (
    echo [*] Copying ccode.exe...
    copy /Y "ccode.exe" "%INSTALL_DIR%\ccode.exe" >nul
) else (
    echo [!] Error: ccode.exe not found!
    echo     Please build it first using: pyinstaller --onefile ccode.py
    pause
    exit /b 1
)

:: 3. Add to User PATH Environment Variable
echo [*] Registering CommonCode in User PATH...

for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "USER_PATH=%%B"

:: Check if directory is already in PATH
echo !USER_PATH! | find /i "%INSTALL_DIR%" >nul
if %errorlevel% equ 0 (
    echo [*] Path is already configured. Skipping update.
) else (
    if defined USER_PATH (
        set "NEW_PATH=%USER_PATH%;%INSTALL_DIR%"
    ) else (
        set "NEW_PATH=%INSTALL_DIR%"
    )
    reg add "HKCU\Environment" /v PATH /t REG_EXPAND_SZ /d "!NEW_PATH!" /f >nul
    echo [+] Successfully registered in User PATH!
)

echo.
echo =========================================
echo   Installation Complete!
echo =========================================
echo Open a NEW Command Prompt or PowerShell window and test:
echo   ccode script.ccode
echo.
pause